
from __future__ import annotations
from abc import ABC, abstractmethod
from uuid import uuid4
from Ship import Ship
#from Containers import Container


import haversine as hs


class IPort(ABC):

    @abstractmethod
    def incoming_ship(self, ship: Ship):
        pass

    @abstractmethod
    def outgoing_ship(self, ship: Ship):
        pass


class Port(IPort):

    def __init__(self, latitude: float, longitude: float) -> None:
        self.id = uuid4()
        self.latitude = latitude
        self.longitude = longitude
        self.containers = []
        self.ship_history = []
        self.current_ships = []

    def __str__(self) -> str:
        return f"ID: {self.id}\nLatitude: {self.latitude}\nLongitude: {self.longitude}\nCurrentShips: {self.current_ships}"

    def get_distance(self, port) -> float:
        dist = hs.haversine((self.latitude, self.longitude), (port.latitude, port.longitude))
        return dist

    def incoming_ship(self, ship: Ship) -> bool:
        if isinstance(ship, Ship) and ship not in self.current_ships:
            self.current_ships.append(ship)
            print(f"successfully add ship {ship.id} to current ship list.")
            return True
        else:
            print(f"Failed to add ship {ship.id} to current ship list.")
            return False

    def outgoing_ship(self, ship: Ship) -> bool:
        if isinstance(ship, Ship) and ship in self.current_ships:
            self.ship_history.append(ship)
            print(f"Ship {ship.id} was successfully added to port {self.id}.")
            return True
        else:
            print(f"Failed to load ship {ship.id} to port {self.id}.")
            return False


