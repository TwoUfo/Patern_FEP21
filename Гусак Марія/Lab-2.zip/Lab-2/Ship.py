from abc import ABC, abstractmethod
from dataclasses import dataclass
from uuid import uuid4
from Port import Port
from Containers import Container




@dataclass
class ConfigShip:
    total_weight_capacity: int
    max_number_of_all_containers: int
    maxNumberOfHeavyContainers: int
    maxNumberOfRefrigeratedContainers: int
    maxNumberOfLiquidContainers: int
    fuelConsumptionPerKM: float


class IShip(ABC):

    @abstractmethod
    def sail_to(self, port) -> bool:
        pass

    @abstractmethod
    def refuel(self, amount_of_fuel: float) -> None:
        pass

    @abstractmethod
    def load(self, container) -> bool:
        pass

    @abstractmethod
    def unload(self, container) -> bool:
        pass


class Ship(IShip):
    """Ship implementation"""

    def __init__(self, port: Port, ship_config: ConfigShip, fuel: float = 0.0) -> None:
        self.id = uuid4()
        self.fuel = fuel
        self.port = port
        self.configs = ship_config
        self.containers = []

    def __str__(self) -> str:
        return f"id: {self.id}\nfuel: {self.fuel}\nport: {self.port}\nconfigs:\n\t{self.configs}\ncontainers: {self.containers}"

    def get_current_containers(self, ship_config: ConfigShip) -> list:
        if isinstance(ship_config, ConfigShip) and ConfigShip.max_number_of_all_containers <= (ConfigShip.maxNumberOfHeavyContainers + ConfigShip.maxNumberOfRefrigeratedContainers + ConfigShip.maxNumberOfLiquidContainers):
            print(f"Ship {self.id} was got to {self.containers} successfully.")
            return self.containers

    def sail_to(self, port: Port) -> bool:
        if isinstance(port, Port):
            if port.get_distance(port) // ConfigShip.fuelConsumptionPerKM < self.fuel:
                print(f"Ship {self.id} was sent containers {port.id} successfully.")
                return True
            else:
                print(f"Ship {self.id} now have {self.fuel} and has been successfully sent to port {port.id}")
                return False

    def refuel(self, amount_of_fuel: float) -> None:
        if amount_of_fuel < 0:
            print(f"{amount_of_fuel} liters has been added to {self.fuel}")
            self.fuel = amount_of_fuel + self.fuel

    def load(self, container: Container) -> bool:
        for container in self.containers:
            if isinstance(container, Container) and container.weight <= self.configs.total_weight_capacity:
                print(f"Container {container} has been successfully loaded.")
                self.containers.append(container)
                self.port.containers.remove(container)
                return True
            else:
                print(f"Failed to load container: {container}.")
                return False

    def unload(self, container: Container) -> bool:
        for containerItem in self.containers:
            if isinstance(container, Container) and containerItem.id == container.id:
                self.containers.remove(containerItem)
                self.port.containers.append(containerItem)
                print(f"Container {containerItem.id} was successfully unloaded.")
                return True
            else:
                print(f"Container with ID {container.id} not found.")
                return False
