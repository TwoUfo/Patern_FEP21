class Bill:
    def __init__(self, id_operator, sum):
        self.id_operator = id_operator
        self.sum = sum
