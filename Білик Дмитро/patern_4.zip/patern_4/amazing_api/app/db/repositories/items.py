from sqlalchemy.orm import Session
from sqlalchemy.future import select
from sqlalchemy import update
from app.models import models
from app.schemas.items import Item, BasicItem, HeavyItem, RefrigeratedItem, LiquidItem

class ItemsRepository:
    def __init__(self, db_session: Session) -> None:
        self.db_session = db_session

    def create_item(self, item: Item) -> models.Items:
        type = ""
        if isinstance(item, BasicItem):
            type = "basic_item"
        elif isinstance(item, HeavyItem):
            type = "heavy_item"
        elif isinstance(item, RefrigeratedItem):
            type = "refrigerated_item"
        elif isinstance(item, LiquidItem):
            type = "liquid_item"
        else:
            raise Exception("unknown item type")

        if item.port_id == -1:
            port_id = None
        else:
            port_id = item.port_id

        db_item = models.Items(id=item.id, type=type, weight=item.weight, port_id=port_id)
        self.db_session.add(db_item)
        self.db_session.commit()
        self.db_session.refresh(db_item)
        return db_item

    def get_by_id(self, item_id: int) -> models.Items:
        item = self.db_session.execute(
            select(models.Items).filter(models.Items.id == item_id)
        )
        return item.scalars().first()

    def get_all_items(self):
        items = self.db_session.execute(select(models.Items).order_by(models.Items.id))
        return items.scalars().all()

    def update(self, item: Item) -> models.Items:
        type = ""
        if isinstance(item, BasicItem):
            type = "basic_item"
        elif isinstance(item, HeavyItem):
            type = "heavy_item"
        elif isinstance(item, RefrigeratedItem):
            type = "refrigerated_item"
        elif isinstance(item, LiquidItem):
            type = "liquid_item"
        else:
            raise Exception("unknown item type")

        item_update = (
            update(models.Items)
            .values(type=type, weight=item.weight)
            .where(models.Items.id == item.id)
        )

        item_update.execution_options(synchronize_session="fetch")
        self.db_session.execute(item_update)
        self.db_session.commit()
        return
