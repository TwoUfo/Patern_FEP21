﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab_3;
using static Lab_3.Program;

namespace Tests.Containers
{
    [TestClass]
    public class ContainerTests
    {
        [TestMethod]
        public void TestContainerConsumption_ShouldReturnCorrectValue()
        {
            // Arrange
            var container = new BasicContainer(1, 100);

            // Act
            var consumption = container.Consumption();

            // Assert
            Assert.AreEqual(250.0, consumption);
        }
    }
}
