using System.Collections.Generic;
using Lab_3;
using static Lab_3.Program;

public class MockPort : IPort
{
    public List<Ship> IncomingShips { get; } = new List<Ship>();
    public List<Ship> OutgoingShips { get; } = new List<Ship>();

    public void IncomingShip(Ship ship)
    {
        IncomingShips.Add(ship);
    }

    public void OutgoingShip(Ship ship)
    {
        OutgoingShips.Add(ship);
    }
}
