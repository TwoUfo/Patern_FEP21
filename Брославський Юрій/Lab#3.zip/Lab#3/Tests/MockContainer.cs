using Lab_3;

public class MockContainer : Container
{
    public MockContainer(int id, int weight) : base(id, weight) { }

    public override double Consumption()
    {
        return 2.50 * Weight;
    }

    public override void GetContainerInfo()
    {
        // Mock implementation
    }
}
