﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab_3;
using System.Collections.Generic;

namespace Tests.Ships
{
    [TestClass]
    public class ShipTests
    {
        [TestMethod]
        public void TestSailTo_EnoughFuel_ShouldReturnTrue()
        {
            // Arrange
            var port1 = new MockPort();
            var port2 = new MockPort();
            var ship = new Ship(1, 1000, 10, 10, 10, 10, 1.0);
            ship.CurrentPort = port1;

            // Act
            var result = ship.SailTo(port2);

            // Assert
            Assert.IsTrue(result);
            Assert.AreEqual(port2, ship.CurrentPort);
        }
    }
}

public class MockPort : IPort
{
    public List<Ship> IncomingShips { get; } = new List<Ship>();
    public List<Ship> OutgoingShips { get; } = new List<Ship>();

    public void IncomingShip(Ship ship)
    {
        IncomingShips.Add(ship);
    }

    public void OutgoingShip(Ship ship)
    {
        OutgoingShips.Add(ship);
    }
}
